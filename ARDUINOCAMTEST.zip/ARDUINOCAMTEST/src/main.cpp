// src/main.cpp

#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <ArduCAM.h>
#include <memorysaver.h>          // comes with the ArduCAM library
#include <stdlib.h> 
#include <sys/unistd.h>

// uncomment exactly one of these two to pull in the OV2640 register set
//#define OV2640_CAM             // if you have the “plain” OV2640 shield
#define OV2640_MINI_2MP_PLUS     // since you’re on the 2 MP Plus module

// choose your CS pin––on the Disco IoT board you can wire CS up to the
// Arduino “D10” header, which is PA2 under the hood:
static constexpr uint8_t CS_PIN = PA2;

// instantiate for JPEG capture
ArduCAM myCAM(OV2640, CS_PIN);

void setup() {
  Serial.begin(115200);
  while (!Serial) { /* wait for USB‑Serial to come up */ }
  Serial.println(F("ArduCAM Mini 2MP Plus test"));

  // start I²C and SPI
  Wire.begin();
  SPI.begin();
  SPI.beginTransaction(SPISettings(8'000'000, MSBFIRST, SPI_MODE0));

  // initialize camera
  myCAM.InitCAM();
  myCAM.set_format(JPEG);
  myCAM.InitCAM();            // some boards need a second Init
  myCAM.clear_fifo_flag();
  myCAM.start_capture();
}

void loop() {
  // wait for capture done
  if ( myCAM.get_bit(ARDUCHIP_TRIG, CAP_DONE_MASK) ) {
    Serial.println(F("Capture done, dumping JPEG..."));

    uint32_t len = myCAM.read_fifo_length();
    if (len == 0 || len > MAX_FIFO_SIZE) {
      Serial.println(F("  ‼️  FIFO error"));
    } else {
      // burst‑read the FIFO and push bytes straight out over Serial
      myCAM.CS_LOW();
      myCAM.set_fifo_burst();
      while (len--) {
        uint8_t b = SPI.transfer(0x00);
        Serial.write(b);
      }
      myCAM.CS_HIGH();
      Serial.println(F("\n✔️  JPEG sent"));
    }

    // start the next frame
    myCAM.clear_fifo_flag();
    myCAM.start_capture();
  }
  delay(1000);
}
